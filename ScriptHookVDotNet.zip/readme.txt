Copy right's go to the real owner's over the sciptvdotnet

To install drag and drop the scripts into root of the gta5/scripts

Requreiments for this too work!
Scripthookv
Scripthookdotnet
nativeui